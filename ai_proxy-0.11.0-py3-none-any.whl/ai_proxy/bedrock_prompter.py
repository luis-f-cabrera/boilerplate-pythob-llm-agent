import json
import botocore.session
import requests
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from ai_proxy.ai_proxy import AIProxyExceptions
import math
from ai_proxy.prompter import Prompter


class BedrockPrompter(Prompter):
    def __init__(self, model=None, **kwargs):
        super().__init__(**kwargs)
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self._model_name = model
        self._base_url = "https://bedrock.us-west-2.amazonaws.com/model/{model}/invoke"
        if model:
            self._base_url = self._base_url.format(model=self._model_name)
        self.session = botocore.session.get_session()
        self.credentials = self.session.get_credentials()

    def set_model(self, model):
        """
        Ser LLM string.
        """
        self._model_name = model
        self._base_url = self._base_url.format(model=self._model_name)

    def estimate_usage(self, prompt, response):
        """
        Estimate usage using the length of the string.
        """
        usage = {
            "prompt_tokens": int(math.ceil(len(prompt) / 4)),
            "completion_tokens": int(math.ceil(len(response) / 4)),
            "total_tokens": int(math.ceil(len(prompt) / 4))
            + int(math.ceil(len(response) / 4)),
        }
        return usage

    def generate_answer(self, prompt, params=None):
        """
        Generates text based on an instruction prompt.
        """
        prompt_template = """Human:{prompt}\nAssistant:""".format(prompt=prompt)
        payload = {
            "prompt": prompt_template,
            "temperature": 0,
            "max_tokens_to_sample": 600,
        }

        if params is not None:
            payload.update(params)

        signed_aws_request = self.sign_request(
            method="POST",
            url=self._base_url,
            data=json.dumps(payload),
            headers=self._headers,
        )

        response = self.make_request(
            method="POST",
            url=self._base_url,
            data=json.dumps(payload),
            headers=signed_aws_request.headers,
        ).json()

        usage = self.estimate_usage(prompt_template, response["completion"])
        # Get chat completion from response
        chat_completion = response["completion"]

        results = {
            "model": self._model_name,
            "next_content": chat_completion,
            "usage": response.get("usage", usage),
        }

        return results

    def find_in_chain(self, chain: dict, action_type="action"):
        """
        Find if the chain contains an invalid element.
        """
        for e in chain:
            if e["type"] == action_type:
                return True
        return False

    def run_chain(self, chain: dict) -> dict:
        """
        Run a chain of prompts, and return the last response.
        Checks if the chain contains valid elements and then runs the parent's method
        """
        if self.find_in_chain(chain=chain, action_type="action"):
            raise AIProxyExceptions(
                {
                    "type": "Chain element not valid for BedrockPrompter class",
                    "value": None,
                    "error": None,
                }
            )
        last_response = super().run_chain(chain)
        return last_response

    def sign_request(self, **kwargs):
        """
        Sign an AWS request
        """
        try:
            sigv4 = SigV4Auth(self.credentials, "bedrock", "us-west-2")
            # Create an AWSRequest object with the request method, data, URL, and headers
            aws_request = AWSRequest(**kwargs)
            sigv4.add_auth(aws_request)
        except Exception as err:
            raise AIProxyExceptions(
                {"type": "Sign request error", "value": None, "error": err}
            )
        return aws_request
