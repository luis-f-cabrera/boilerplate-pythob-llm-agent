"""
"""
from ai_proxy.ai_proxy import AIProxy
from ai_proxy.file_manager import FileManager
from mutagen.mp3 import MP3


class Transcriber(AIProxy):
    def __init__(
        self,
        timeout_limit_by_request=45,
        max_tries_by_request=5,
        time_window=60,
        max_requests_by_time_window=50,
        max_resquests_by_run=7000,
        wait_time_before_retry=5,
        n_parallel_process=16,
        api_key=None,
    ):
        super().__init__(
            timeout_limit_by_request=timeout_limit_by_request,
            max_tries_by_request=max_tries_by_request,
            time_window=time_window,
            max_requests_by_time_window=max_requests_by_time_window,
            max_resquests_by_run=max_resquests_by_run,
            wait_time_before_retry=wait_time_before_retry,
            n_parallel_process=n_parallel_process,
        )

        self.api_key = api_key

    def select_api_url(self):
        return "https://api.openai.com/v1/audio/transcriptions"

    def select_api_headers(self):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        return headers

    def select_api_model(self):
        return "whisper-1"

    def get_audio_length(self, local_audio_path):
        audio = MP3(local_audio_path)
        return audio.info.length

    def get_response_content(self, response):
        try:
            return response.json()
        except:
            return {"text": response.text}

    def transcribe_local_audio(self, audio_path, language, min_audio_length):
        """
        If language is None, then language will be infered by the model.
        """

        url = self.select_api_url()
        headers = self.select_api_headers()
        model = self.select_api_model()
        api_data = {
            "model": model,
            "language": language,
            "prompt": "Kavak.com. Autos seminuevos.",
        }

        if language is None:
            del api_data["language"]

        files = {"file": open(audio_path, "rb")}
        audio_length = self.get_audio_length(audio_path)
        response = {"metrics": {"audio_length": audio_length}}
        if audio_length >= min_audio_length:
            response["transcription"] = self.get_response_content(
                self.make_request(
                    method="POST", url=url, headers=headers, files=files, data=api_data
                )
            )
            response["transcription"] = (
                {} if response["transcription"] is None else response["transcription"]
            )
        else:
            response["transcription"] = {}
        response["metrics"]["transcript_length"] = (
            None
            if "text" not in response["transcription"]
            else len(response["transcription"]["text"])
        )
        return response

    def run(self, s3_audio_path, language, min_audio_length=0):
        """
        If language is None, then language will be infered by the model.
        """
        local_audio_path = FileManager().download_s3_file(s3_audio_path)
        response = self.transcribe_local_audio(
            audio_path=local_audio_path,
            language=language,
            min_audio_length=min_audio_length,
        )
        FileManager().delete_local_file(local_audio_path)

        return response
