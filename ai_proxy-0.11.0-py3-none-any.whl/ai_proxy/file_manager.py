import boto3
import os
from botocore.exceptions import ClientError


class FileManager:
    def __init__(self):
        self.s3 = boto3.resource("s3")
        self.s3_client = boto3.client("s3")

    def get_bucket_and_key_from_s3_path(self, path):
        assert path[:5] == "s3://", f"{path} is not a valid s3 path"
        return path.split("/")[2], "/".join(path.split("/")[3:])

    def download_s3_file(self, s3_path, local_path=""):
        bucket, key = self.get_bucket_and_key_from_s3_path(s3_path)
        self.s3.Bucket(bucket).download_file(key, local_path + key.split("/")[-1])
        return local_path + key.split("/")[-1]

    def delete_local_file(self, path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            pass
        return None

    def upload_file(self, local_path, s3_path):
        s3_bucket, s3_key = self.get_bucket_and_key_from_s3_path(s3_path)
        with open(local_path, "rb") as f:
            self.s3_client.upload_fileobj(f, s3_bucket, s3_key)

    def s3_file_exists(self, s3_path):
        bucket_name, key = self.get_bucket_and_key_from_s3_path(s3_path)
        try:
            self.s3.Object(bucket_name, key).load()
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return False
            else:
                raise
        else:
            return True

    def list_files(self, s3_path):
        # Eliminar el prefijo "s3://" de la ruta de S3
        path_without_prefix = s3_path.replace("s3://", "")

        # Dividir la ruta en el nombre del bucket y la ruta dentro del bucket
        parts = path_without_prefix.split("/", 1)

        bucket_name = parts[0]
        prefix = "" if len(parts) < 2 else parts[1]

        # Obtener los nombres de los archivos en todas las páginas
        files = []
        response = self.s3_client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=prefix,
        )
        contents = response.get("Contents", [])
        files.extend([obj["Key"] for obj in contents])
        continuation_token = response.get("NextContinuationToken", None)
        while continuation_token is not None:
            response = self.s3_client.list_objects_v2(
                Bucket=bucket_name, Prefix=prefix, ContinuationToken=continuation_token
            )
            contents = response.get("Contents", [])
            files.extend([obj["Key"] for obj in contents])
            continuation_token = response.get("NextContinuationToken", None)

        return files
