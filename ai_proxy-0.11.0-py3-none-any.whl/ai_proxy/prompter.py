import json
from ai_proxy.ai_proxy import AIProxy
import requests
from ai_proxy.ai_proxy import AIProxyExceptions
import math
import asyncio


class Prompter(AIProxy):
    """
    A service class that wraps the Open AI API to generate text.
    It takes a prompt and generates a response.
    The class inherits from the AI Proxy class, which is a wrapper
    to connect to external APIs, handling authentication, retries,
    and other common tasks such as error handling.
    """

    _default_model_thresholds = {
        "gpt-3.5-turbo-0613": {
            "threshold": 10000,
            "long_context_model": "gpt-3.5-turbo-16k-0613",
        },
        "gpt-3.5-turbo": {
            "threshold": 10000,
            "long_context_model": "gpt-3.5-turbo-16k",
        },
        "gpt-4": {"threshold": 20000, "long_context_model": "gpt-4-32k"},
        "gpt-4-0613": {"threshold": 20000, "long_context_model": "gpt-4-32k-0613"},
    }
    _default_base_url = "https://api.openai.com/v1/chat/completions"

    def __init__(
        self,
        api_key=None,
        base_url=None,
        model=None,
        model_auto_scale=True,
        model_thresholds=None,
        **kwargs,
    ):
        """
        Constructor for the Prompter class.
        """
        super().__init__(**kwargs)
        self._api_key = api_key
        self._base_url = self._default_base_url if base_url is None else base_url
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
        }
        self._model_name = "gpt-3.5-turbo-0613" if model is None else model
        self._model_auto_scale = model_auto_scale
        self._model_thresholds = (
            self._default_model_thresholds
            if model_thresholds is None
            else model_thresholds
        )
        # LLM Memory
        self._vars = {}
        self.tools = {}

    def check_chain_condition(self, condition):
        """Return the result of a condition statement from a chain definition component."""
        [a, b] = condition[1:]
        if condition[0] == "eq":
            return self.parse_chain_variable(a) == self.parse_chain_variable(b)
        if condition[0] == "in":
            return (
                self.parse_chain_variable(a).lower()
                in self.parse_chain_variable(b).lower()
            )
        return False

    def format_keys(self, dictionary):
        new_dictionary = {}
        for key in dictionary.keys():
            new_key = key if key.startswith("$") else f"${key}"
            new_dictionary[new_key] = dictionary[key]

        return new_dictionary

    def parse_json_format(self, response):
        """
        Given a string containing a json, it is formatted to ensure that the key is preceded by a "$"
        and is defined between square brackets.
        """
        parsed_response = response.replace("$", "").replace("{", "").replace("}", "")
        parsed_response = json.loads("{" + parsed_response + "}")
        parsed_response = json.dumps(self.format_keys(parsed_response))
        return parsed_response

    def select_gpt_model(self, message):
        model_name = self._model_name

        if (
            self._model_auto_scale
            and (self._model_name in self._model_thresholds)
            and (len(message) >= self._model_thresholds[self._model_name]["threshold"])
        ):
            model_name = self._model_thresholds[self._model_name]["long_context_model"]

        return model_name

    def set_tools(self, tools):
        self.tools = tools

    async def agenerate_answer(self, prompt, params=None):
        """
        Generates text based on an instruction prompt.
        """
        model = self.select_gpt_model(prompt)
        payload = {
            "messages": [{"role": "user", "content": prompt}],
            "model": model,
            "temperature": 0,
        }

        if params is not None:
            payload.update(params)

        response = await self.make_async_request(
            method="POST",
            url=self._base_url,
            data=json.dumps(payload),
            headers=self._headers,
        )

        # Get chat completion from response
        chat_completion = response["choices"][0].get("message", {}).get("content", None)
        function_call = (
            response["choices"][0].get("message", {}).get("function_call", None)
        )

        results = {
            "model": model,
            "next_content": chat_completion,
            "usage": response.get("usage", None),
        }
        if function_call is not None:
            results["function_call"] = function_call

        return results

    def generate_answer(self, prompt, params=None):
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(self.agenerate_answer(prompt, params=params))
        return results

    def generate_answer_from_file(self, file_path):
        """
        Generates text based on an instruction prompt stored in a local file.
        """
        with open(file_path, "r") as file:
            prompt = file.read()
        return self.generate_answer(prompt)

    @classmethod
    def map_chain(cls, chain, filter_fn, apply_fn):
        """
        For all elements in chain, apply_fn if filter_fn is True.
        Recursively traverse lists and elements of type "condition".
        """
        new_chain = []
        for element in chain:
            if isinstance(element, list):
                new_chain.append(cls.map_chain(element, filter_fn, apply_fn))
            elif filter_fn(element):
                element = apply_fn(element)
                new_chain.append(element)
            elif element["type"] == "condition":
                # Recursive processing of condition branches
                branches = element["condition"][1:3]
                new_chain.append(
                    {
                        **element,
                        "condition": [
                            element["condition"][0],
                            cls.map_chain(branches[0], filter_fn, apply_fn),
                            cls.map_chain(branches[1], filter_fn, apply_fn),
                        ],
                    }
                )
            else:
                new_chain.append(element)
        return new_chain

    def parse_chain_variable(self, varstring):
        """Return the value of a variable, or the variable itself if it's not part of a prompt chain."""
        is_var = isinstance(varstring, str) and varstring.startswith("$")
        return self._vars.get(varstring, None) if is_var else varstring

    def run(self, prompt):
        return self.generate_answer(prompt)

    async def arun(self, prompt):
        return await self.agenerate_answer(prompt)

    def run_chain(self, chain: dict) -> dict:
        """
        Run a chain of prompts, and return the last response.
        The main loop follows a FIFO approach in order to scan nested prompts.
        Note that the chain is processed in reverse to achieve this effect.
        """
        # Init the chain in a simple stack
        to_process = chain[::-1]
        last_response = None
        last_usage = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        }

        while len(to_process) > 0:
            # Follow FIFO
            component = to_process.pop()
            if component["type"] == "prompt":
                # Inject any known variable to the prompt, then run
                prompt = component["message"].format(**self._vars)
                params = component.get("params", None)
                res = self.generate_answer(prompt, params)

                output_type = component.get("output", "text")

                # For prompts defined with output=json, parse the response
                if output_type == "json":
                    parsed_response = self.parse_json_format(res["next_content"])
                    try:
                        parsed_content = json.loads(parsed_response)
                        # Update the vars in memory with the parsed content
                        self._vars = {**self._vars, **parsed_content}
                    except Exception as e:
                        print("Unable to parse as JSON:", res["next_content"])
                        raise e

                # Accumulate usage counters
                last_usage = self.sum_keys(last_usage, res["usage"])
                last_response = {
                    **res,
                    "usage": last_usage,
                }
            elif component["type"] == "condition":
                # Check condition
                # Based on the result, update the stack with the correct branch
                statement = component["condition"]
                branches = statement[1:3]
                if self.check_chain_condition(statement[0]):
                    to_process += branches[0][::-1]
                else:
                    to_process += branches[1][::-1]
            elif component["type"] == "action":
                prompt = component["message"].format(**self._vars)
                params = component.get("params", None)
                res = self.generate_answer(prompt, params)
                try:
                    parsed_content = json.loads(res["function_call"]["arguments"])
                    parsed_content = self.format_keys(parsed_content)
                    self._vars = {**self._vars, **parsed_content}
                except Exception as e:
                    print("Unable to parse as JSON:", res["next_content"])
                    raise e
                try:
                    func_output = self.tools[res["function_call"]["name"]](**self._vars)
                    self._vars = {**self._vars, **func_output}
                except Exception as e:
                    print("Unable to run tool: ", component["tool"])
                    raise e
                # Accumulate usage counters
                last_usage = self.sum_keys(last_usage, res["usage"])
                last_response = {
                    **res,
                    "usage": last_usage,
                }
            else:
                print("Ignoring unknown component")

        return last_response

    @classmethod
    def sum_keys(cls, a, b):
        """For each matching key in b from a, sum the values."""
        return {k: a[k] + b.get(k, 0) for k in a}
