from datetime import datetime
import json
import multiprocessing
import requests
import time
from tqdm import tqdm
from ai_proxy.file_manager import FileManager
import aiohttp
import asyncio


class AIProxyExceptions(Exception):
    def __init__(self, arg):
        self.arg = arg


class AIProxy:
    """
    class variables:
        timeout_limit_by_request: time limit in seconds for an individual request
        max_tries_by_request: maximum number of retries
        time_window: define a time window in seconds for a maximum number of requests in that window
        max_requests_by_time_window: maximum number of requests in a time window
        max_resquests_by_run:
            when running run_in_parallel, this parameter is the max number of processed requests in one single run
            if params' length is greater than this parameter, the first max_resquests_by_run will
            be processed normaly and the remaining will return a diccionary with the key 'attempts': []
            indicating that these requests have been skipped
        wait_time_before_retry: wating time in seconds before retrying a request
        n_parallel_process: max number of request running in parallel
    """

    def __init__(
        self,
        timeout_limit_by_request=45,
        max_tries_by_request=3,
        time_window=60,
        max_requests_by_time_window=50,
        max_resquests_by_run=7000,
        wait_time_before_retry=5,
        n_parallel_process=16,
    ):
        self.timeout_limit_by_request = timeout_limit_by_request
        self.max_tries_by_request = max_tries_by_request
        self.time_window = time_window
        self.max_requests_by_time_window = max_requests_by_time_window
        self.max_resquests_by_run = max_resquests_by_run
        self.wait_time_before_retry = wait_time_before_retry
        self.n_parallel_process = n_parallel_process

    def make_request(self, **kwargs):
        """
        Makes a request to an external API.
        """
        try:
            response = requests.request(**kwargs, timeout=self.timeout_limit_by_request)
            response.raise_for_status()
            return response
        except requests.exceptions.Timeout as err:
            raise AIProxyExceptions(
                {"type": "TimeoutError", "value": None, "error": err}
            )
        except requests.exceptions.HTTPError as err:
            raise AIProxyExceptions(
                {"type": "HTTPError", "value": err.response.status_code, "error": err}
            )
        except requests.exceptions.ConnectionError as err:
            raise AIProxyExceptions(
                {"type": "ConnectionError", "value": None, "error": err}
            )
        except requests.exceptions.RequestException as err:
            raise AIProxyExceptions({"type": "unknown", "value": None, "error": err})

    async def make_async_request(self, **kwargs):
        """
        Makes an async request to an external API with aiohttp.
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    timeout=aiohttp.ClientTimeout(total=self.timeout_limit_by_request),
                    **kwargs,
                ) as response:
                    # Check for HTTP errors
                    response.raise_for_status()

                    return await response.json()

        except asyncio.exceptions.TimeoutError as err:
            raise AIProxyExceptions(
                {"type": "TimeoutError", "value": None, "error": err}
            )
        except aiohttp.ClientResponseError as err:
            raise AIProxyExceptions(
                {"type": "HTTPError", "value": err.status, "error": err}
            )
        except aiohttp.ClientConnectionError as err:
            raise AIProxyExceptions(
                {"type": "ConnectionError", "value": None, "error": err}
            )
        except aiohttp.ClientError as err:
            raise AIProxyExceptions({"type": "unknown", "value": None, "error": err})

    def run(*args, **kwargs):
        """
        To be defined in the child class.
        """
        pass

    async def arun(*args, **kwargs):
        """
        To be defined in the child class.
        """
        pass

    def run_with_retry(self, data, eval_=True):
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(self.arun_with_retry(data, eval_))
        return results

    async def arun_with_retry(self, data, eval_=True):
        answer = {"input": data, "attempts": []}
        if not eval_:
            return answer

        success = False
        try_ = 0
        while (not success) & (try_ < self.max_tries_by_request):
            try_ += 1
            try:
                start_time = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")
                response = await self.arun(*data)
                answer["attempts"].append(
                    {
                        "try": try_,
                        "start_timestamp_utc": start_time,
                        "end_timestamp_utc": datetime.utcnow().strftime(
                            "%Y-%m-%d %H:%M:%S.%f"
                        ),
                        "next_try_wating_time": None,
                        "exception": None,
                        "success": True,
                        "response": response,
                    }
                )
                success = True
            except Exception as e:
                if isinstance(e, AIProxyExceptions):
                    exception_message = e.arg
                else:
                    exception_message = e
                wt = (
                    self.wait_time_before_retry * try_
                    if try_ < self.max_tries_by_request
                    else None
                )
                answer["attempts"].append(
                    {
                        "try": try_,
                        "start_timestamp_utc": start_time,
                        "end_timestamp_utc": datetime.utcnow().strftime(
                            "%Y-%m-%d %H:%M:%S.%f"
                        ),
                        "next_try_wating_time": wt,
                        "exception": exception_message,
                        "success": False,
                        "response": None,
                    }
                )
                if wt is not None:
                    time.sleep(wt)

        return answer

    def run_in_parallel(self, params):
        """
        params must be a list containing the set of parameters to be
        evaluated in the run method.
        Examples:
        params = ['prompt1 ....', 'prompt2 ....', ...]
        params = [('mp3_path1', 'es'), ('mp3_path2', 'en'), ...]
        """

        pool = multiprocessing.Pool(
            self.n_parallel_process
        )  # Create a pool of processes
        results = []
        eval_flag = [
            True for _ in range(min(len(params), self.max_resquests_by_run))
        ] + [False for _ in range(max(0, len(params) - self.max_resquests_by_run))]

        total_params = len(params)
        with tqdm(total=total_params) as pbar:
            results = []
            available_request = self.max_requests_by_time_window
            running_request = []

            def update_progress(result):
                # Callback function to update results and the progress bar
                results.append(result)
                pbar.update(1)

            def handle_error(error):
                print(error, flush=True)

            while True:
                # Check if there are more params to process and available request slots
                if params and available_request > 0:
                    # Select a subset of params to process in the current minute
                    subset = params[: min(available_request, len(params))]
                    params = params[len(subset) :]

                    # Select de eval flag
                    subset_flags = eval_flag[: len(subset)]
                    eval_flag = eval_flag[len(subset) :]

                    # Launch processes for the selected subset
                    processes = [
                        pool.apply_async(
                            self.run_with_retry,
                            (
                                param,
                                flag,
                            ),
                            callback=update_progress,
                            error_callback=handle_error,
                        )
                        for param, flag in zip(subset, subset_flags)
                    ]
                    running_request.extend(processes)

                if not params:
                    time.sleep(0.1)
                else:
                    time.sleep(self.time_window)  # sleep the time window

                # Reset available_request at the beginning of each window
                running_request = [p for p in running_request if not p.ready()]
                available_request = self.max_requests_by_time_window - len(
                    running_request
                )
                if not params and not running_request:
                    # Break the loop when all params have been processed and no more requests are running
                    break

        pool.close()
        pool.join()
        return results

    @classmethod
    def save_metrics(cls, data, s3_path):
        timestring = datetime.utcnow().strftime("%Y_%m_%d_%H_%M_%S.%f")
        filename = f"AIProxy_observability_{timestring}.json"
        observability_path = f"{s3_path}/{filename}"

        with open(filename, "w") as file:
            file.write(json.dumps(data, default=lambda x: str(x)))

        fm = FileManager()
        fm.upload_file(filename, observability_path)
        fm.delete_local_file(filename)

        return True
